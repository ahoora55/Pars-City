'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Server } = require('socket.io');
const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const ROOM = 'PARS-CITY';
const MAX_PLAYERS = Number(process.env.MAX_PLAYERS || 35);
const players = new Map();
const indexPath = path.join(ROOT, 'index.html');
const server = http.createServer((req, res) => {
  const pathname = new URL(req.url, 'http://localhost').pathname;
  if (pathname === '/health') {
    res.writeHead(200, {'content-type':'application/json; charset=utf-8','cache-control':'no-store'});
    return res.end(JSON.stringify({ok:true,game:'Pars City',server:ROOM,players:players.size,maxPlayers:MAX_PLAYERS}));
  }
  if (pathname === '/' || pathname === '/index.html') {
    res.writeHead(200, {'content-type':'text/html; charset=utf-8','cache-control':'no-store'});
    return fs.createReadStream(indexPath).pipe(res);
  }
  res.writeHead(404, {'content-type':'text/plain; charset=utf-8'}); res.end('Not found');
});
const io = new Server(server, { cors: { origin: '*' }, pingInterval: 25000, pingTimeout: 20000, maxHttpBufferSize: 1e5 });
function safeName(v) { return String(v || 'بازیکن').replace(/[<>\u0000-\u001f]/g,'').trim().slice(0,20) || 'بازیکن'; }
function safePosition(p) {
  if (!p || !Number.isFinite(p.x) || !Number.isFinite(p.z) || !Number.isFinite(p.angle)) return null;
  return {x:Math.max(-500,Math.min(500,p.x)),z:Math.max(-500,Math.min(500,p.z)),angle:((p.angle%(Math.PI*2))+Math.PI*2)%(Math.PI*2),inCar:!!p.inCar,carType:String(p.carType||'pride').slice(0,24)};
}
io.on('connection', socket => {
  socket.data.joined = false;
  socket.data.lastMoveAt = 0;
  socket.on('joinRoom', data => {
    if (socket.data.joined) return;
    const requested = String((data && data.server) || ROOM);
    if (requested !== ROOM) return socket.emit('joinError', {message:'این سرور در دسترس نیست.'});
    if (players.size >= MAX_PLAYERS) return socket.emit('roomFull', {server:ROOM});
    socket.data.joined = true;
    socket.data.name = safeName(data && data.name);
    socket.data.position = {x:0,z:0,angle:0,inCar:false,carType:'pride'};
    const player = {id:socket.id,name:socket.data.name,position:socket.data.position};
    players.set(socket.id,player);
    socket.join(ROOM);
    socket.emit('roomJoined',{room:ROOM,id:socket.id,players:[...players.values()]});
    socket.to(ROOM).emit('playerJoined',player);
  });
  socket.on('move', data => {
    if (!socket.data.joined) return;
    const now = Date.now();
    if (now - socket.data.lastMoveAt < 45) return;
    socket.data.lastMoveAt = now;
    const position=safePosition(data); if(!position)return;
    socket.data.position=position;
    const player=players.get(socket.id); if(!player)return;
    player.position=position;
    socket.to(ROOM).emit('playerMoved',{id:socket.id,name:socket.data.name,position});
  });
  socket.on('disconnect',()=>{
    if(!players.has(socket.id)) return;
    players.delete(socket.id);
    socket.to(ROOM).emit('playerLeft',{id:socket.id});
  });
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Pars City online server listening on ${PORT}; room=${ROOM}; max=${MAX_PLAYERS}`));
